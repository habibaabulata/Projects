# 1
x = [6, 6, 3, 4, 3]
y = set(x)
print(list(y))

# 2
x = [6, 6, 3, 4, 3]
z = []
for i in x:
    if i not in z:
        z.append(i)
print(z)

# 3
x = int(input("Please input a number: "))
y = x
i = 0
while x > 0:
    z = x % 10
    i = i * 10 + z
    x = x // 10
if y == i:
    print("The number is a palindrome!")
else:
    print("The number is NOT a palindrome!")

# 4
n = int(input("Please input a number: "))
y = n
z = 0
while n > 1:
    z = z + 1
    n = n / 2
if y % 2 != 0: z = z - 1
print("Log2Approx (", y, ")=", z)

# 5
import random

i = 0
u = 2
while i != u:
    m = ["rock", "paper", "scissors"]
    z = random.choice(m)
    x = input("Please input a choice: ")
    if x == z:
        print("Computer chose:", z, "it’s a tie!")
    elif x == "scissors":
        if z == "rock":
            print("Computer chose:", z, "computer wins")
        else:
            print("Computer chose:", z, "you win")
    elif x == "rock":
        if z == "paper":
            print("Computer chose:", z, "computer wins")
        else:
            print("Computer chose:", z, "you win")
    elif x == "paper":
        if z == "scissors":
            print("Computer chose:", z, "computer wins")
        else:
            print("Computer chose:", z, "you win")
    elif x == "exit":
        break
    else:
        print("ERROR please choose one of the following:(rock, paper, scissors,or exit)")
