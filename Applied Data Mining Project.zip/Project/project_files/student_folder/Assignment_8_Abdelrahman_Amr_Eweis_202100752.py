
# 1
def removeLargeWords(Words, n):
    new_words = [i for i in Words if len(i) <= n]
    return new_words


y = removeLargeWords('this is an example'.split(), 4)
print(y)


# 2
def getVowels(s):
    vowels = ["a", "i", "e", "o", "u"]
    s2 = [vow for vow in s if vow in vowels]
    return s2


y = getVowels('this is an example')
print(y)


# 3
def calcDiv(list1, list2):
    list3 = []
    for x, y in zip(list1, list2):
        try:
            z = x / y
            list3.append(z)
        except ZeroDivisionError:
            pass
    return list3


y = calcDiv([2, 30, 15, 5], [1, 10, 5, 0])
print(y)


# 4
class Cube:
    def __init__(self, edge):
        self.edge = edge

    def getArea(self):
        a = 6 * (self.edge ** 2)
        return a

    def getVolume(self):
        v = self.edge ** 3
        return v

    def setedge(self, edgenew):
        edgenew = self.edge


edge = float(input("Please, enter the edge of the cube: "))
cube = Cube(edge)
print(cube.getArea())
print(cube.getVolume())



# 5
class Library:
    def __init__(self, bookList={}, booksBorrowed=[]):
        self.bookList = bookList
        self.booksBorrowed = booksBorrowed

    def borrowBook(self, bookname):
        if bookname in self.bookList:
            if self.bookList[bookname][1] > 0:
                self.booksBorrowed.append(bookname)
                self.bookList[bookname][1] -= 1
            else:
                print("sorry there no more copies from that book")
        else:
            print("sorry we don't even have this book")

    def returnBook(self, bookname):
        if bookname in self.bookList:
            self.bookList[bookname][1] = self.bookList[bookname][1] + 1
            self.booksBorrowed.remove(bookname)
        else:
            print("you didn't borrow this book from us")

    def displayDetails(self):
        for i in self.bookList:
            print("Title: %s,Author(s): %s, number of copies: %s" % (i, self.bookList[i][0], self.bookList[i][1]))


library = Library({'The Great Gatsby': ['F. Scott Fitzgerald', 2], 'To Kill a Mockingbird': ['Harper Lee', 1],
                   'The Lord of The Rings': ['J. R. R. Tolkien', 3]})
library.borrowBook('The Lord of The Rings')
library.borrowBook('The Catcher in The Rye')
library.returnBook('Frankenstein')
library.displayDetails()


# 6
with open('Employees_IDs.txt', "r") as f1, open('Employees_Data.txt', "r") as f2:
    l1 = f1.readlines()
    l2 = f2.readlines()
for x in range(len(l1)):
    l1[x] = l1[x].strip()
    l2[x] = l2[x].strip()
employeeInfo = {}
for x, y in zip(l1, l2):
    z = y.split(",")
    employeeInfo[x] = {'name': z[0], 'jobTitle': z[1], 'salary': z[2]}
print(employeeInfo)

# 7
import pickle

employeePickle = open('Employees.pkl', 'wb')
pickle.dump(employeeInfo, employeePickle)
employeePickle.close()
