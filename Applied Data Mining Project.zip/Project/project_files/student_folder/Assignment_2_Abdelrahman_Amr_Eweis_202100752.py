

#1
from math import pow
s = int( input("Please input the length of the square side: "))
p= s*4
a= int(pow(s,2))
print("This square area = ", a)
print("This square perimeter = ", p)





#2
d=int(input("Please input the distance (in KM): "))
t=int(input("Please input the estimated time (in minutes): "))
u=float(5+(d*2)+(t*0.5))
c=float(7+(d*3)+(t*0.3))
print("The cost using Uber will be:", u)
print("The cost using Careem will be:", c)





#3
from math import pow,sqrt 
x=int(input("Please input x1:"))
y=int(input("Please input y1:"))
z=int(input("Please input x2:"))
w=int(input("Please input y2:"))
d=sqrt((pow((z-x),2))+(pow((w-y),2)))
rd=round(d,2)
print("The distance between ",(x,y),"and",(z,w),"=",rd)





#4
x=float(input("Please input a float number: "))
y=(x-int(x))
print("The fraction part of this number is: ",y)
print("The integral part is: ",int(x))




#5
from random import randint
x=randint(1,6)
print("you rolled ", x)