# 1

s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
print("S1 union S2 = ", s1.union(s2))
print("S1 intersection S2 = ", s1.intersection(s2))

# 2

x = int(input("Please input the first number: "))
y = int(input("Please input the second number: "))

z = set([])
if y > x:
    for i in range(x, y):
        if i % 2 != 0:
            z.add(i)
else:
    print("Incorrect input!!! The second number should be greater than the first.")

if y > x:
    print("The odd numbers between ", x, "and", y, "are", z)

# 3

x = int(input("Please input a number: "))
print("Here is the multiplication table for", x, ":")
for w in range(1, 13):
    print(x, "x", w, "=", x * w)

# 4

from random import randint
x = randint(1, 51)
y = int(input("Please guess a number between 1 and 50: "))
for i in range(5):
    if y > x:
        y = int(input("Incorrect, try to guess a smaller number:"))
    elif y < x:
        y = int(input("Incorrect, try to guess a bigger number:"))
    else:
        print("Woooow!!! Well done :) You got it!!")
        break

#5
x=int(input("Please input a number: "))
y=1
for i in range(1,x+1):
    y=y*i
print("the factorial of", x, "is: ",y)

# bonus

iterations = int(input("Enter the number of iterations: "))
pi = 0
y = 1
for i in range(1, iterations + 1):
    if i % 2 != 0: pi = pi + (1/y)
    else:
        pi = pi - (1/y)
    z = pi * 4
    y = y + 2

print("The approximation of pi is ", z)
