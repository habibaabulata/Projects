# 1
def analyzeString(str):
    d = 0
    l = 0
    for i in str:
        if i.isdigit():
            d = d + 1
        elif i.isalpha():
            l = l + 1
        else:
            pass
    print("Letters = ", l)
    print("Digits = ", d)


analyzeString('I got 5 out of 7 answers correct')


# 2
def printAge(name, year):
    z = 2021 - year
    print("Welcome", name, "! You are", z, "years old :)")


printAge("mohamed", 1980)


# 3
def removeN(inStr, index):
    x = inStr[:index]
    y = inStr[index + 1:]
    z = x + y
    return z


print(removeN("Computer", 0))
print(removeN("Hello", 3))


# 4

def Series(x, y):
    x = str(x)
    z = 0
    for i in range(1, y + 1):
        z = z + int(x * i)
    print(z)


Series(2, 5)


# 5
def adjust(num):
    num = int(num)
    num = str(num)
    if len(num) < 2:
        num = "0" + num
        return num
    else:
        return num


print(adjust(2))
print(adjust(20))


# 6
def adjust(num):
    num = int(num)
    num = str(num)
    if len(num) < 2:
        num = "0" + num
        return num
    else:
        return num


def time_format(seconds):
    seconds = int(seconds)
    z = 0
    i = 3600
    j = 60
    y = 0
    while i < seconds:
        if seconds > 3600:
            seconds = seconds - 3600
            z = z + 1
    while j < seconds:
        if seconds > 60:
            seconds = seconds - 60
            y = y + 1
    m = adjust(y)
    h = adjust(z)
    s = adjust(seconds)
    t = (h + ":" + m + ":" + s)
    return t


print(time_format(7424))


# 7
def count(inStr, subStr):
    x = inStr.find(subStr)
    y = inStr.rfind(subStr)
    return x, y


print(count("mississippi", "ss"))
