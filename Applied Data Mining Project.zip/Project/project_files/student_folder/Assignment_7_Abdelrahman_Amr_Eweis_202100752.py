# 1
def sortBySum(d):
    values = list(d.values())
    val1 = values[0]
    val2 = values[1]
    keys = list(d.keys())
    key1 = keys[0]
    key2 = keys[1]
    d2 = dict()
    t1 = 0
    t2 = 0
    for i in val1:
        t1 = t1 + i
    for j in val2:
        t2 = t2 + j
    if t1 > t2:
        d2[key2] = t2
        d2[key1] = t1
    elif t2 > t1:
        d2[key1] = t1
        d2[key2] = t2
    return d2


d = {'best': [7, 6, 5], 'worst': [6, 7, 4]}
print(sortBySum(d))


# 2
def force_insert(d, key, value):
    d = dict(d)
    d2 = d.copy()
    if key not in d:
        d[key] = value
    elif key in d:
        d[key] = [d2.get(key), value]
    return d


print(force_insert({1: 'a'}, 1, 'b'))
print(force_insert({1: 'a'}, 2, 'b'))


# 3
def calcSim(fname):
    try:
        f = open(fname)
        val1 = int(f.readline())
        add = val1
        mult = val1
        div = val1
        luka = val1
        x = f.readlines()
        for i in x:
            i = int(i)
            add = add + i
            mult = mult * i
            div = div / i
            luka = luka - i
        print("Addition=", add, ", Subtraction=", luka, "Multiplication=", mult, ", Division=", div)
        f.close()
    except ZeroDivisionError:
        print("Error division by zero")
    except FileNotFoundError:
        print("the file you are trying to reach doesn't exist")
    except:
        print("An Unknown Error has occurred")


calcSim("numbers.txt")


# 4
def swap(d, key1, key2):
    d = dict(d)
    keys = d.keys()
    d2 = d.copy()
    if key1 and key2 in keys:
        d[key1] = d2[key2]
        d[key2] = d2[key1]
        print(d)
    elif key1 not in keys:
        print(key1, "is not a key in the dictionary")
    elif key2 not in keys:
        print(key2, "is not a key in the dictionary")


swap({1: 'a', 2: 'b'}, 1, 2)
swap({1: 'a', 2: 'b'}, 1, 3)


# 5
def line_sum(f):
    file = open(f)
    x = list(file.readlines())
    x.reverse()
    for i in x:
        i = str()
        for j in x:
            i = i + j
    file = open(f, "w")
    file.writelines(i)
    file.flush()


line_sum('q5.txt')

f = "q6.txt"


def line_sum(f):
    file = open(f, "r")
    results = list()
    l = list()
    for i in file:
        l.append(i.split(","))
    for j in l:
        z = 0
        for h in j:
            z = z + int(h)
        results.append(str(z))
    yo = open("results.txt", "w")
    yo.write("\n".join(results))


line_sum('q6.txt')
