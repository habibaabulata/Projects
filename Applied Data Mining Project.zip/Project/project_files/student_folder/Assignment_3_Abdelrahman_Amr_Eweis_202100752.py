
#1
"""
a) True and False or True                                (True)
b) (True and False) and False                            (False)
c) Not (True or False) and True                          (False)
d) Not ((Not True or Not False) or (False and True))     (False)
"""

#2
x=int(input('please input  your age: '))
y=int(input('please input your BMI: '))
if (x<45) and (y<22):
    print("Your body Mass is Low")
elif (x>=45) and (y<22):
    print("Your body Mass is Medium")
elif (x>=45) and (y>=22):
    print("Your body Mass is High")
else:
    print("Your body Mass is Medium")
#3
y=int(input("Please input the width of the first rectangle: "))
x=int(input("Please input the length of the first rectangle: "))
z=int(input("Please input the width of the second rectangle: "))
w=int(input("Please input the length of the second rectangle: "))
a1=int(y*x)
a2=int(z*w)
if a2>a1:print("The area of rectangle 2 is greater than the are of rectangle 1")
else:
    print("The area of rectangle 1 is greater than the are of rectangle 2 ")


#4
from random import choice
q=["Happiness is when what you think, what you say, and what you do are in harmony", "There is only one happiness in life, to love and be loved", "Be happy for this moment. This moment is your life", "Happiness lies in the joy of achievement and the thrill of creative effort", "Be kind whenever possible. It is always possible"]
print(choice(q))

#5
L=[11, 45, 8, 23, 14, 12, 78, 45, 89]
x=int(len(L)/3)
y=x+int(len(L)/3)
z=y+int(len(L)/3)
p1=L[:x]
p2=L[x:y]
p3=L[y:z]
print(p1,p2,p3)


#6
L=[6, 20, 15]
print("Please select an option from the following menu:")
print("1- Append number to the list")
print("2- Add number in a specific position in the list")
print("3- Display the length of the list")
print("4- Sort the list")
print("5- Check if an element in the List")
c=int(input())
if c==1:
    x=int(input("Please enter a number "))
    L.append(x)
    print("The list= ",L)
elif c==2:
    x = int(input("Please enter a number "))
    y=int(input("Please enter location of number "))
    L.insert(y,x)
    print("The list= ",L)
elif c==3:
    print("The list length= ",len(L))
elif c==4:
    print("The list= ",sorted(L))
elif c==5:
    x = int(input("Please enter a number "))
    if x in L: print("Yes")
    else: print("No")
else:
    print("ERROR please enter a number from 1 to 5")
